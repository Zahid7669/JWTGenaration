const { handler } = require('./index.js');

(async () => {
  const auth = 'Basic ' + Buffer.from('admin:admin').toString('base64');
  const event = {
    headers: {
      'content-type': 'application/x-www-form-urlencoded',
      'authorization': auth
    },
    body: 'grant_type=client_credentials',
    isBase64Encoded: false
  };
  const res = await handler(event);
  console.log('RESPONSE', res.statusCode, res.body);
})();
