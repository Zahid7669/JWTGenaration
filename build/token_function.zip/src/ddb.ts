import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand } from '@aws-sdk/lib-dynamodb';
import { awsEndpoint } from './utils';
import type { ClientRow } from './types';

const ddbClient = new DynamoDBClient({
  endpoint: awsEndpoint(),
  region: process.env.AWS_REGION || 'eu-west-1',
});

const ddb = DynamoDBDocumentClient.from(ddbClient);
const TABLE = process.env.USERS_TABLE || 'Users';

export async function getClientByUsername(username: string): Promise<ClientRow | null> {
  const res = await ddb.send(new GetCommand({
    TableName: TABLE,
    Key: { Username: username },
  }));

  const item = res.Item as Record<string, any> | undefined;
  if (!item) return null;

  // Normalize: Username -> client_id, Password -> client_secret
  const row: ClientRow = {
    client_id: item.Username,
    client_secret: item.Password,
    client_secret_hash: item.client_secret_hash,         // if you ever add it
    allowed_scopes: item.allowed_scopes ?? [],           // default empty
    audience: item.audience ?? 'urn:cujo:apis',
    issuer: item.issuer ?? 'https://auth.local',
    token_ttl_seconds: item.token_ttl_seconds ?? 3600,   // 1 hour default
  };

  return row;
}
