import { GetPublicKeyCommand, KMSClient, SignCommand } from '@aws-sdk/client-kms';
import { awsEndpoint, base64url } from './utils';

/**
 * Sign JWT using AWS KMS alias/signing-key with RS256.
 */
const kms = new KMSClient({
  endpoint: awsEndpoint(),
  region: process.env.AWS_REGION || 'eu-west-1',
});

const KEY_ALIAS = process.env.KMS_KEY_ALIAS || 'alias/signing-key';

export async function signJwtRS256(payload: Record<string, unknown>): Promise<string> {
  // Resolve KeyId and use as kid
  const pub = await kms.send(new GetPublicKeyCommand({ KeyId: KEY_ALIAS }));
  const kid = pub.KeyId || KEY_ALIAS;

  const header = { alg: 'RS256', typ: 'JWT', kid };
  const encHeader = base64url(JSON.stringify(header));
  const encPayload = base64url(JSON.stringify(payload));
  const signingInput = `${encHeader}.${encPayload}`;

  const { Signature } = await kms.send(new SignCommand({
    KeyId: KEY_ALIAS,
    Message: Buffer.from(signingInput),
    MessageType: 'RAW',
    SigningAlgorithm: 'RSASSA_PKCS1_V1_5_SHA_256',
  }));

  if (!Signature) throw new Error('KMS returned empty signature');
  return `${signingInput}.${base64url(Buffer.from(Signature))}`;
}
