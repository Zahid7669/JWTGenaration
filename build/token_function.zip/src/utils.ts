export function base64url(input: Buffer | string): string {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buf.toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

export function parseForm(body: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  const params = new URLSearchParams(body || '');
  for (const [k, v] of params.entries()) out[k] = v;
  return out;
}

export function parseBasicAuth(header?: string | null): { client_id: string; client_secret: string } | null {
  if (!header || !header.startsWith('Basic ')) return null;
  const raw = Buffer.from(header.slice(6), 'base64').toString('utf8');
  const idx = raw.indexOf(':');
  if (idx < 0) return null;
  return { client_id: raw.slice(0, idx), client_secret: raw.slice(idx + 1) };
}

export function headerGet(headers: Record<string, string | undefined>, name: string): string | undefined {
  const hit = Object.entries(headers || {}).find(([k]) => k.toLowerCase() === name.toLowerCase());
  return hit?.[1];
}

export function awsEndpoint(): string | undefined {
  // Use Localstack if available; otherwise use real AWS
  if (process.env.AWS_ENDPOINT_URL) return process.env.AWS_ENDPOINT_URL;
  if (process.env.LOCALSTACK_HOSTNAME) return `http://${process.env.LOCALSTACK_HOSTNAME}:4566`;
  return undefined;
}
