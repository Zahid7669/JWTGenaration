import type { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
import { handleTokenRequest } from './oauth';

/**
 * Exported as 'handler' so default Lambda handler "index.handler" works
 * after building to index.js at repo root (no infra changes needed).
 */
export const handler = async (event: APIGatewayProxyEvent): Promise<APIGatewayProxyResult> => {
  try {
    const bodyStr = event.isBase64Encoded
      ? Buffer.from(event.body || '', 'base64').toString('utf8')
      : (event.body || '');

    const res = await handleTokenRequest({
      headers: (event.headers as Record<string, string | undefined>) || {},
      body: bodyStr,
    });

    return {
      statusCode: res.statusCode,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(res.body),
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ error: 'server_error' }),
    };
  }
};
