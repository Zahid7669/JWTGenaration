import bcrypt from 'bcryptjs';
import { getClientByUsername } from './ddb';
import { signJwtRS256 } from './kmsJwt';
import { headerGet, parseForm, parseBasicAuth } from './utils';
import type { TokenError, TokenSuccess } from './types';


export interface RawRequest {
  headers: Record<string, string | undefined>;
  body: string | undefined;
}

export async function handleTokenRequest(
  req: RawRequest
): Promise<{ statusCode: number; body: TokenSuccess | TokenError }> {
  const contentType = headerGet(req.headers, 'content-type') || '';
  if (!/application\/x-www-form-urlencoded/i.test(contentType)) {
    return badRequest('invalid_request', 'content-type must be application/x-www-form-urlencoded');
  }

  const auth = parseBasicAuth(headerGet(req.headers, 'authorization'));
  const form = parseForm(req.body);

  const grantType = form['grant_type'];
  if (grantType !== 'client_credentials') {
    return { statusCode: 400, body: { error: 'unsupported_grant_type' } };
  }

  // Accept credentials via Basic Auth or form body
  const presentedId = auth?.client_id || form['client_id'];
  const presentedSecret = auth?.client_secret || form['client_secret'];

  if (!presentedId || !presentedSecret) {
    return badRequest('invalid_request', 'missing client credentials');
  }

  // In your schema: Username = client id, Password = client secret (plaintext)
  const client = await getClientByUsername(presentedId);
  if (!client) {
    return unauthorized();
  }

  // If both plaintext and hash exist, support either (doesn't change your data)
  if (client.client_secret) {
    if (client.client_secret !== presentedSecret) return unauthorized();
  } else if (client.client_secret_hash) {
    const ok = await bcrypt.compare(presentedSecret, client.client_secret_hash);
    if (!ok) return unauthorized();
  } else {
    // No usable secret present in row
    return unauthorized();
  }

  const now = Math.floor(Date.now() / 1000);
  const ttl = client.token_ttl_seconds ?? 3600;
  const scope = (client.allowed_scopes ?? []).join(' ');

  const payload = {
    iss: client.issuer ?? 'https://auth.local',
    sub: client.client_id,
    aud: client.audience ?? 'urn:cujo:apis',
    scope,
    iat: now,
    exp: now + ttl,
  };

  const jwt = await signJwtRS256(payload);

  return {
    statusCode: 200,
    body: {
      access_token: jwt,
      token_type: 'Bearer',
      expires_in: ttl,
      scope: scope || undefined,
    },
  };
}

function badRequest(error: TokenError['error'], error_description?: string) {
  return { statusCode: 400, body: { error, error_description } as TokenError };
}

function unauthorized() {
  return { statusCode: 401, body: { error: 'invalid_client' } as TokenError };
}
