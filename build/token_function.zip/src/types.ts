export interface ClientRow {
  client_id: string;              // normalized from Username
  client_secret?: string;         // normalized from Password (plaintext)
  client_secret_hash?: string;    // (optional) if you ever add hashed secrets
  allowed_scopes?: string[];
  audience?: string;
  issuer?: string;
  token_ttl_seconds?: number;
}

export interface TokenSuccess {
  access_token: string;
  token_type: 'Bearer';
  expires_in: number;
  scope?: string;
}

export type TokenErrorCode =
  | 'invalid_request'
  | 'unsupported_grant_type'
  | 'invalid_client'
  | 'server_error';

export interface TokenError {
  error: TokenErrorCode;
  error_description?: string;
}
