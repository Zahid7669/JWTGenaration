'use strict';

const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, GetCommand } = require('@aws-sdk/lib-dynamodb');
const { KMSClient, GetPublicKeyCommand, SignCommand } = require('@aws-sdk/client-kms');
const bcrypt = require('bcryptjs');

/* ===================== Utilities ===================== */

function base64url(input) {
  const buf = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return buf.toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function parseForm(body) {
  const out = {};
  const params = new URLSearchParams(body || '');
  for (const [k, v] of params.entries()) out[k] = v;
  return out;
}

function parseBasicAuth(header) {
  if (!header || !header.startsWith('Basic ')) return null;
  const raw = Buffer.from(header.slice(6), 'base64').toString('utf8');
  const idx = raw.indexOf(':');
  if (idx < 0) return null;
  return { client_id: raw.slice(0, idx), client_secret: raw.slice(idx + 1) };
}

function headerGet(headers, name) {
  if (!headers) return undefined;
  const target = name.toLowerCase();
  for (const [k, v] of Object.entries(headers)) {
    if (String(k).toLowerCase() === target) return v;
  }
  return undefined;
}

function awsEndpoint() {
  if (process.env.AWS_ENDPOINT_URL) return process.env.AWS_ENDPOINT_URL;
  if (process.env.LOCALSTACK_HOSTNAME) return `http://${process.env.LOCALSTACK_HOSTNAME}:4566`;
  return undefined; // real AWS if undefined
}

/* ===================== AWS Clients ===================== */

const REGION = process.env.AWS_REGION || 'eu-west-1';
const DDB = DynamoDBDocumentClient.from(new DynamoDBClient({
  endpoint: awsEndpoint(),
  region: REGION
}));
const KMS = new KMSClient({
  endpoint: awsEndpoint(),
  region: REGION
});

const USERS_TABLE = process.env.USERS_TABLE || 'Users';
const KMS_KEY_ALIAS = process.env.KMS_KEY_ALIAS || 'alias/signing-key';

/* ===================== Data Access ===================== */
/**
 * Your Users table rows look like:
 * { Username: "admin", Password: "admin" }
 * We keep that as-is, and normalize to an internal shape.
 */
async function getClientByUsername(username, password) {

    console.log('Table', USERS_TABLE);

  const res = await DDB.send(new GetCommand({
    TableName: USERS_TABLE,
    Key: { Username: username, Password: password }
  }));

  console.log('DDB RES', res);
  const item = res.Item;
  if (!item) return null;

  return {
    client_id: item.Username,
    client_secret: item.Password,        // plaintext secret supported
    client_secret_hash: item.client_secret_hash, // optional, if ever present
    allowed_scopes: item.allowed_scopes || [],
    audience: item.audience || 'urn:cujo:apis',
    issuer: item.issuer || 'https://auth.local',
    token_ttl_seconds: item.token_ttl_seconds || 3600
  };
}

/* ===================== KMS JWT Signing ===================== */

async function signJwtRS256(payload) {
  // Resolve kid from the key id
  const pub = await KMS.send(new GetPublicKeyCommand({ KeyId: KMS_KEY_ALIAS }));
  const kid = pub.KeyId || KMS_KEY_ALIAS;

  const header = { alg: 'RS256', typ: 'JWT', kid };
  const encHeader = base64url(JSON.stringify(header));
  const encPayload = base64url(JSON.stringify(payload));
  const signingInput = `${encHeader}.${encPayload}`;

  const { Signature } = await KMS.send(new SignCommand({
    KeyId: KMS_KEY_ALIAS,
    Message: Buffer.from(signingInput),
    MessageType: 'RAW',
    SigningAlgorithm: 'RSASSA_PKCS1_V1_5_SHA_256'
  }));

  if (!Signature) throw new Error('KMS returned empty signature');
  return `${signingInput}.${base64url(Signature)}`;
}

/* ===================== OAuth Logic ===================== */

function badRequest(error, error_description) {
  return { statusCode: 400, body: { error, error_description } };
}
function unauthorized() {
  return { statusCode: 401, body: { error: 'invalid_client' } };
}

async function handleTokenRequest(req) {
  const contentType = headerGet(req.headers, 'content-type') || '';
  if (!/application\/x-www-form-urlencoded/i.test(contentType)) {
    return badRequest('invalid_request', 'content-type must be application/x-www-form-urlencoded');
  }

  console.log('REQUEST', req);

  const auth = parseBasicAuth(headerGet(req.headers, 'authorization'));
  const form = parseForm(req.body);

  console.log('AUTH', auth);

  console.log('FORM', form);

  const grantType = form['grant_type'];
  if (grantType !== 'client_credentials') {
    return { statusCode: 400, body: { error: 'unsupported_grant_type' } };
  }

  const presentedId = (auth && auth.client_id) || form['client_id'];

  console.log('PRESENTED ID', presentedId);

  const presentedSecret = (auth && auth.client_secret) || form['client_secret'];
  if (!presentedId || !presentedSecret) {
    return badRequest('invalid_request', 'missing client credentials');
  }

  // Load client by Username in your schema
  const client = await getClientByUsername(presentedId, presentedSecret);

  if (!client) return unauthorized();

  // Check secret (plaintext or bcrypt hash if present)
  if (client.client_secret != null) {
    if (client.client_secret !== presentedSecret) return unauthorized();
  }
  else {
    return unauthorized();
  }

  const now = Math.floor(Date.now() / 1000);
  const ttl = client.token_ttl_seconds || 3600;
  const scopeStr = Array.isArray(client.allowed_scopes) ? client.allowed_scopes.join(' ') : '';

  const payload = {
    iss: client.issuer || 'https://auth.local',
    sub: client.client_id,
    aud: client.audience || 'urn:cujo:apis',
    scope: scopeStr,
    iat: now,
    exp: now + ttl
  };

  console.log('PAYLOAD', payload);
  const jwt = await signJwtRS256(payload);

  const body = {
    access_token: jwt,
    token_type: 'Bearer',
    expires_in: ttl
  };
  if (scopeStr) body.scope = scopeStr;

  return { statusCode: 200, body };
}

/* ===================== Lambda Handler ===================== */

exports.handler = async (event) => {
  try {
    const bodyStr = event && event.isBase64Encoded
      ? Buffer.from(event.body || '', 'base64').toString('utf8')
      : ((event && event.body) || '');

    const res = await handleTokenRequest({
      headers: (event && event.headers) || {},
      body: bodyStr
    });

    return {
      isBase64Encoded: false,
      statusCode: res.statusCode,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(res.body)
    };
  } catch (err) {
    console.error('Unhandled error in handler:', err);
    return {
      isBase64Encoded: false,
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'server_error' })
    };
  }
};
